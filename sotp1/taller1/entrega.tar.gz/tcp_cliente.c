#include "mt.h"

int main(int argc, char *argv[]){

	struct sockaddr_in remote;
	
	struct in_addr dirip;
	
	char str[MAX_MSG_LENGTH];
	char str_recv[MAX_MSG_LENGTH];
	int conv;

	int s;
	ssize_t len;
	
	//ssize_t ss;
	
	//printf ("%s\n", argv[1]);
	
	conv = inet_aton (argv[1], &dirip);
	if (conv == 0){	
		perror ("Mal formato de la direccion ip");
		exit(1);
	}
	
	if ((s = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		perror("creando socket");
		exit(1);
	}
	
	
	remote.sin_family = AF_INET;
	remote.sin_port = htons(PORT);
	remote.sin_addr = dirip;
	
	if (connect(s, (void*) &remote, sizeof(remote)) == -1) {
		perror("No nos pudimos conectar :(");
		exit(1);
	}
	
	//system("sleep 10");
	
	while(printf("> "), fgets(str, MAX_MSG_LENGTH, stdin), strncmp(str, END_STRING, 5)) {
		//sleep(1000);
        send(s, str, strlen(str) + 1, 0);
        len = recv(s, str_recv, 1024, 0);
        str_recv[len] = 0;
        printf("%s\n", str_recv);
    }
	
	return 0;
}
