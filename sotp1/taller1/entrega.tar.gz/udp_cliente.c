#include "mt.h"

int main(int argc, char *argv[]){

	struct sockaddr_in remote;
	
	struct in_addr dirip;
	
	char str[MAX_MSG_LENGTH];
	
	int conv;

	int s;
	
	//ssize_t ss;
	
	//printf ("%s\n", argv[1]);
	
	conv = inet_aton (argv[1], &dirip);
	if (conv == 0){	
		perror ("Mal formato de la direccion ip");
		exit(1);
	}
	
	if ((s = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
		perror("creando socket");
		exit(1);
	}
	
	
	remote.sin_family = AF_INET;
	remote.sin_port = htons(PORT);
	remote.sin_addr = dirip;
	
	
	while(printf("> "), fgets(str, MAX_MSG_LENGTH, stdin), strncmp(str, END_STRING, 5)) {
        sendto(s, str, strlen(str) + 1, 0, (void*) &remote, sizeof(remote));
    }
	
	close(s);
	return 0;
}
