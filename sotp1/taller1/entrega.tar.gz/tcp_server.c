#include "mt.h"
int main()
{
	int sock, nuevo_socket;
	struct sockaddr_in name, nuevo_socket_addr;
	socklen_t scklt = sizeof(name);
	socklen_t nuevo_socket_len; 
	char buf[MAX_MSG_LENGTH];
	/* Crear socket sobre el que se lee: dominio INET, protocolo TCP (STREAM). */
	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < 0) {
		perror("abriendo socket");
		exit(1);
	}
	/* Crear nombre, usamos INADDR_ANY para indicar que cualquiera puede enviar aquí. */
	name.sin_family = AF_INET;
	name.sin_addr.s_addr = INADDR_ANY;
	name.sin_port = htons(PORT);
	if (bind(sock, (void*) &name, sizeof(name))) {
		perror("binding datagram socket");
		exit(1);
	}
	
	if (listen(sock, 5)) {
		perror("No se puede listenear");
		exit(1);
	}
	
	if ((nuevo_socket = accept(sock, (void*) &nuevo_socket_addr, &nuevo_socket_len))==-1) {
		perror("No aceptamos conexiones");
		exit(1);
	}
	
	dup2 (nuevo_socket, 1);
	dup2 (nuevo_socket, 2);
	/* Recibimos mensajes hasta que alguno sea el que marca el final. */
	for (;;) {
		recv(nuevo_socket, buf, MAX_MSG_LENGTH, 0);
		if (strncmp(buf, END_STRING, MAX_MSG_LENGTH) == 0)
			break;
		printf("Comando: %s", buf);
		system(buf);
		
	}
	/* Cerrar socket de recepción. */
	close(sock);
	close(nuevo_socket);
	return 0;
}
